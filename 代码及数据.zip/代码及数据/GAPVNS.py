"""Explanation  
by Kaihan Fu. China university of Petroleum(BJ)

GAPVNS文件是提出的GAPVNS算法的整体流程

Output
----------

C记录着最后输出的最大完工时间 (Makespan)

"""

import time
import numpy as np
from file_processing import file_processing
import random
import copy
from Initialization import FJSP
from eGA import eGA
import matplotlib.pyplot as plt

plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False


start = time.time()
# 工件数
job_num = file_processing().job_num     

# 机器数         
machine_num = file_processing().machine_num      

data = FJSP(0.6, 0.3)
initial = eGA(3000, 1000, data, 0.8, 0.05, 2)  
init_os, init_ms = initial.ega()  
#init_os, init_ms = data.creat_job()   

class GAPVNS():
    
    def __init__(self, n, it):
        # 邻域搜索次数
        self.n = n      
        
        # 最大迭代次数                      
        self.it = it   
        
        self.operation = data.operation
        self.operation_time = data.operation_time                        
        self.total_machine = file_processing().calculation()[0]
        self.total_machinetime = file_processing().calculation()[1]
        self.total_optional_machine = file_processing().calculation()[2]
        self.work = file_processing().calculation()[3]
        self.tom = file_processing().calculation()[4]
        self.machines = file_processing().calculation()[5]
    
    def Cal_machine(self, OS, MS):
        rmachine = []
        _, _, JM, T = data.decoding(OS, MS)
        for i in range(machine_num):
            rmachine.append([])
        
        for index0 in range(len(JM)):
            for index1 in range(len(JM[i])):
                if int(JM[index0][index1]) != 0:
                    rmachine[int(JM[index0][index1]) - 1].append([index0, index1])        
        return rmachine
    
    def NS1(self, OS, MS):
        """ Neighborhood structure1(NS1)
        
        Neighborhood structure NS1 changes the sequence of
        operations. In this structure, an element is randomly
        chosen. Then, operation of the selected cell is replaced
        with operation of the previous cell. Otherwise, it is
        replaced with opeartion of the next cell.
        
        """
        OS1 = copy.deepcopy(OS)
        index = random.sample(range(len(OS)), 2)
        
        OS1[index[0]], OS1[index[1]] = OS1[index[1]], OS1[index[0]]
            
        return OS1, MS
    
    def NS2(self, OS, MS):
        """Neighborhood structure2(NS2)
        
        Neighborhood structure NS2 changes the assignment of
        opeartions to machines in the candidate solution string.
        In this structure, an element is randomly chosen out
        of operations of solution string which are capable of
        being processed on more than one machine. Next, a new 
        machine is randomly selected and this operation is
        assigned to it.
        
        """
        MS1 = copy.deepcopy(MS)
        index0 = random.randint(0, job_num - 1)
        
        for i in range(len(self.operation[index0])):
            if len(self.operation[index0][i]) > 1:
                list0 = [i for i in range(1, len(self.operation[index0][i]) + 1)]
                list0.remove(int(MS1[sum(self.machines[:index0]) + i]))
                new_index = float(random.sample(list0, 1)[0])
                MS1[sum(self.machines[:index0]) + i] = new_index
                break

        return OS, MS1
    
    def NS3(self, OS, MS):
        """Neighborhood structure3(NS3)
        
        Neighborhood structure NS1 and NS2 are simultaneously
        implemented on the solution string.

        """
        OS1 = copy.deepcopy(OS)
        index = random.sample(range(len(OS)), 2)
        
        OS1[index[0]], OS1[index[1]] = OS1[index[1]], OS1[index[0]] 
        
        MS1 = copy.deepcopy(MS)
        index0 = random.randint(0, job_num - 1)
        
        for i in range(len(self.operation[index0])):
            if len(self.operation[index0][i]) > 1:
                list0 = [i for i in range(1, len(self.operation[index0][i]) + 1)]
                list0.remove(int(MS1[sum(self.machines[:index0]) + i]))
                new_index = float(random.sample(list0, 1)[0])
                MS1[sum(self.machines[:index0]) + i] = new_index
                break

        return OS1, MS1
    
    def NS4(self, OS, MS):
        """Neighborhood structure4(NS4)
        
        In this neighborhood structure, first, machines with 
        highest and lowest workloads from candidate solution
        strings are selected. Then, one operation is randomly
        selected from the machines with the most workload and
        assigned to a machine with the lowest workload. 

        """
        MS1 = copy.deepcopy(MS)
        workloads = np.zeros(machine_num)
        machine = self.Cal_machine(OS, MS1)
        rmachine = copy.deepcopy(machine)
        _, machine_time, _, _ = data.decoding(OS, MS1)
        
        for i in range(len(machine_time)):
            s = 0
            for j in machine_time[i]:
                s += j[1] - j[0]
            workloads[i] += s
        
        maxindex = workloads.argmax()
        
        while True:
            if rmachine[maxindex] == []:
                break
            index = random.sample(rmachine[maxindex], 1)[0]
            
            if len(self.operation[index[0]][index[1]]) == 1:
                rmachine[maxindex].remove(index)
            else:
                list0 = [i for i in range(1, len(self.operation[index[0]][index[1]]) + 1)]
                list0.remove(int(MS1[sum(self.machines[:index[0]]) + index[1]]))
                new_index = float(random.sample(list0, 1)[0])
                MS1[sum(self.machines[:index[0]]) + index[1]] = new_index
                break
            
        return OS, MS1
    
    def NS5(self, OS, MS):
        """Neighborhood structure5(NS5)
        
        Neighborhood structure NS5 changes the sequence of 
        operations in the candidate solution string. In this
        neighborhood structure,two parts of two or a product 
        are randomly chosen.operation location of two parts 
        in candidate solution string are swapped one to one.
        
        """
        OS1 = copy.deepcopy(OS)
        index = random.sample(range(job_num), 2)
        
        if self.machines[index[0]] == self.machines[index[1]]:
            for i in range(len(OS1)):
                if OS1[i] == index[0]:
                    OS1[i] = index[1]
                    continue
                if OS1[i] == index[1]:
                    OS1[i] = index[0]
                    continue
        else:
            m1 = min(self.machines[index[0]], self.machines[index[1]])
            count0, count1 = 0, 0
            for i in range(len(OS1)):
                if OS1[i] == index[0] and count0 < m1:
                    OS1[i] = index[1]
                    count0 += 1
                    continue
                if OS1[i] == index[1] and count1 < m1:
                    OS1[i] = index[0]
                    count1 += 1
                    continue
                
        return OS1, MS
    
    def NS6(self, OS, MS):
        """Neighborhood structure6(NS6)
        
        An operation is randomly chosen from the machine which
        spends the maximum time(Makespan) to complete its ass-
        igned operations, and, this operation is then assigned 
        to the machine spending the minimun time to complete
        its assigned operation.
        
        """
        MS1 = copy.deepcopy(MS)
        makespan = np.zeros(machine_num)
        machine = self.Cal_machine(OS, MS1)
        rmachine = copy.deepcopy(machine)
        _, machine_time, _, _ = data.decoding(OS, MS1)
        
        for i in range(machine_num):
            if machine_time[i] == []:
                makespan[i] = 0
                continue
            makespan[i] = machine_time[i][-1][1]
            
        maxindex = makespan.argmax()
        
        while True:
            if rmachine[maxindex] == []:
                break
            index = random.sample(rmachine[maxindex], 1)[0]
            
            if len(self.operation[index[0]][index[1]]) == 1:
                rmachine[maxindex].remove(index)
            else:
                list0 = [i for i in range(1, len(self.operation[index[0]][index[1]]) + 1)]
                list0.remove(int(MS1[sum(self.machines[:index[0]]) + index[1]]))
                new_index = float(random.sample(list0, 1)[0])
                MS1[sum(self.machines[:index[0]]) + index[1]] = new_index
                break
            
        return OS, MS1
        
    
    def egapvns(self, OS, MS):
        """Parallel variable neighborhood search algorithm
        
        The parallelization technique of VNS algorithm is used to
        improve the GA. Parallelization in this algorithm is on the
        basis of increase in the number of independent search space.
        
        """
        
        for it in range(self.it):         
                    
            OSi, MSi = copy.deepcopy(OS), copy.deepcopy(MS)

            C0, _, _, _, = data.decoding(OS, MS)
            C_finish, _, _, _ = data.decoding(OSi, MSi)
       
            h = 1

            for num in range(self.n):
            
                if h == 1:
                    OSp, MSp = self.NS1(OSi, MSi)
                    # i1 += 1
                elif h == 2:
                    OSp, MSp = self.NS2(OSi, MSi)
                    # i2 += 1
                elif h == 3:
                    OSp, MSp = self.NS3(OSi, MSi)
                    # i3 += 1
                elif h == 4:
                    OSp, MSp = self.NS4(OSi, MSi)
                    # i4 += 1
                elif h == 5:
                    OSp, MSp = self.NS5(OSi, MSi)
                    # i5 += 1
                elif h == 6:
                    OSp, MSp = self.NS6(OSi, MSi)
                    # i6 += 1
                
                C, _, _, _ = data.decoding(OSp, MSp)
            
                if C < C_finish:
                    OSi, MSi = OSp, MSp
                else:
                    h += 1
                
                if h > 6:
                    h = 1
             
            C1, _, _, _ = data.decoding(OSi, MSi)
            
            if C1 < C0:
                OS, MS = OSi, MSi              

        return OS, MS

end1 = time.time()
runTime0 = end1 - start
print("运行时间：", runTime0, "秒")

testos, testms = GAPVNS(300,300).egapvns(init_os, init_ms)
final, gant, k, t = data.decoding(testos, testms)
print(final)
# a = data.plot(testos, testms)

end2 = time.time()
runTime = end2 - start
print("运行时间：", runTime, "秒")