"""Explanation  
by Kaihan Fu. China university of Petroleum(BJ)


file_processing文件是将FJSP的测试数据进行读取

Output
----------

total_machine记录着每个工件的每道工序可以在哪些机器上加工
total_machinetime记录着每个工件的每道工序在total_machine对应的加工机器上的加工时间
total_optional_machine记录着每个工件的每道工序可供加工的加工机器数
machines记录着每个工件有几道工序
tom记录着每道工序可加工机器的索引值

"""

import numpy as np

class file_processing:

    def __init__(self):
        """
        job_num : the numbers of jobs
        machine_num : the numbers of machines
        a : the data of the constraints

        """
        
        file = open(r'data\MK10.txt')
        file1 = file.readlines()
        a = []
        for line in file1:                    
            b = []
            t1 = line.strip('\n').split(' ')
            for i in t1:
                b.append(int(i))
            a.append(b)
            
        # 工件数    
        self.job_num = a[0][0]

        # 机器数                                     
        self.machine_num = a[0][1]  
                                  
        self.a = a[1:len(a)]

    def data_classification(self,line):                   
        """Process each line of data in the file
        """

        sigdex = []
        machine,machinetime,optional_machine = [],[],[]
        
        # total_procedure_num记录了某件工件共有几道工序
        total_procedure_num = line[0]       
              
        line = line[1:len(line)]
        index = 0
        
        for j in range(total_procedure_num):
            
            # a代表每个工序可供加工的机器数量
            a = line[index]     

            # optional_machine记录着每个工序可供加工的机器数量                          
            optional_machine.append(a)                   
            sigdex.append(index)
            index = index + 1 + 2 * a

        for i in range(total_procedure_num):
            del line[sigdex[i] - i]                      

        for i in range(0,len(line)-1,2):
            machine.append(line[i])
            machinetime.append(line[i + 1])

        return machine, machinetime, optional_machine

    def calculation(self):                             
        """Calculate the related information        
        """
        txt = self.a
        widthx = []

        for i in range(self.job_num):
            machine, machinetime, optional_machine = self.data_classification(txt[i])
            siga = len(machine)
            widthx.append(siga)
        width = max(widthx)

        total_machine = np.zeros((self.job_num, width))
        total_machinetime = np.zeros((self.job_num, width))   
        
        # total_optional_machine记录着所有工件每个工序可被加工的机器数量
        total_optional_machine = []                                

        for i in range(self.job_num):
            machine, machinetime, optional_machine = self.data_classification(txt[i])
            total_optional_machine.append(optional_machine)
            siga = len(machine)
            total_machine[i, 0:siga] = machine 
            
            # total_machine记录着所有工序可被哪些机器加工
            total_machinetime[i, 0:siga] = machinetime             
        
        to, tom, work, machines = 0, [], [], []

        for i in range(self.job_num):
            to += len(total_optional_machine[i])
            tim = []
            
            for j in range(1, len(total_optional_machine[i]) + 1):
                tim.append(sum(total_optional_machine[i][0:j]))
                # work中每个数字的个数表示每个工件的工序数
                work.append(i)    
                                        
            machines.append(len(total_optional_machine[i]))
            tom.append(tim)
        
        return total_machine, total_machinetime, total_optional_machine, work, tom, machines


to = file_processing()
Tmachine,Tmachinetime,total_optional_machine,work,tom,machines = to.calculation()
# print(total_optional_machine)
# print(machines)
