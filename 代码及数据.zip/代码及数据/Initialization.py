"""Explanation  
by Kaihan Fu. China university of Petroleum(BJ)

Initialzation文件是FJSP问题的编码解码与初始化

operation记录着每个工序可在哪些机器上加工
operation_time记录着相应的加工时间

creat_job()是种群的初始化
decoding()是解码

Output
----------

OS是工序选择部分
MS是机器选择部分
final是最大完工时间(makespan)
machinetime是记载每个机器上加工的工序

"""

import numpy as np
from file_processing import file_processing
import random
import matplotlib.pyplot as plt
from matplotlib.pylab import mpl

mpl.rcParams['font.sans-serif'] = ['SimHei'] 
index = ['M1', 'M2', 'M3', 'M4', 'M5', 'M6', 'M7', 'M8', 'M9', 'M10',
         'M11', 'M12', 'M13', 'M14', 'M15', 'M16', 'M17', 'M18', 'M19', 'M20'] 
scale_ls, index_ls = [], []
color = ['#FFCC00', '#99CCFF', '#FF99CC', '#FFCC99', '#3366FF', '#33CCCC', '#99CC00', '#FFCC00', '#FF9900', '#FFFF99',
         '#CCFFCC', '#00CCFF', '#CCFFFF', '#FFFF00', '#666699', '#969696', '#339966', '#FF6600', 'red', 'blue']

class FJSP():
    
    def __init__(self, p1, p2):
        # 工件数
        self.job_num = file_processing().job_num     

        # 机器数
        self.machine_num = file_processing().machine_num 
        
        # 全局选择的概率
        self.p1 = p1    

        # 局部选择的概率                                      
        self.p2 = p2   
                                       
        self.total_machine = file_processing().calculation()[0]
        self.total_machinetime = file_processing().calculation()[1]
        self.total_optional_machine = file_processing().calculation()[2]
        self.work = file_processing().calculation()[3]
        self.tom = file_processing().calculation()[4]
        self.machines = file_processing().calculation()[5]
        
        operation, operation_time = [], []
        
        for i in range(self.job_num):
            operation.append([])
            operation_time.append([])
            
            for j in range(self.machines[i]):
                upper = self.tom[i][j]
                lower = self.tom[i][j] - self.total_optional_machine[i][j]
            
                om = self.total_machine[i, lower:upper].tolist() 
                omt = self.total_machinetime[i, lower:upper].tolist() 
            
                operation[i].append(om)
                operation_time[i].append(omt)
                
        self.operation = operation
        self.operation_time = operation_time        
        
    def GS(self):
        
        globel = np.zeros(self.machine_num)
        MS = np.zeros(sum(self.machines))
        
        Job = []
        
        for i in range(self.job_num):
            Job.append(i)
            
        while True:
            index = random.choice(Job)
            
            for i in range(self.machines[index]):
                temp = np.zeros(len(self.operation[index][i]))
                
                for j, k in enumerate(self.operation[index][i]):
                    temp[j] += self.operation_time[index][i][j]
                    temp[j] += globel[int(k) - 1]
                
                final = temp.argmin()
                globel[int(self.operation[index][i][final]) - 1] = min(temp)
                
                if index == 0:
                    MS[i] += final + 1
                else:
                    MS[int(sum(self.machines[:index])) + i] += final + 1
                    
            Job.remove(index)
            if Job == []:
                break
                                
        return MS
     
    def LS(self):
        
        MS = np.zeros(sum(self.machines))
        
        for index in range(self.job_num):
            local = np.zeros(self.machine_num)
            
            for i in range(self.machines[index]):
                temp = np.zeros(len(self.operation[index][i]))
                
                for j, k in enumerate(self.operation[index][i]):
                    temp[j] += self.operation_time[index][i][j]
                    temp[j] += local[int(k) - 1]
                    
                final = temp.argmin()
                local[int(self.operation[index][i][final]) - 1] = min(temp)
                
                if index == 0:
                    MS[i] += final + 1
                else:
                    MS[int(sum(self.machines[:index])) + i] += final + 1
              
        return MS
     
    def RF(self):
        
        MS = np.zeros(sum(self.machines))
        
        for index in range(self.job_num):
            
            for i in range(self.machines[index]):
                machine = random.randint(1, len(self.operation[index][i]))
                
                if index == 0:
                    MS[i] += machine
                else:
                    MS[int(sum(self.machines[:index])) + i] += machine
         
        return MS
    
    def creat_job(self):
        
        OS = np.copy(self.work)
        np.random.shuffle(OS)
        OS = np.array(OS).reshape(len(self.work))
        
        r = np.random.rand()
        
        if r <= self.p1:
            
            MS = self.GS()
            
        elif r >= 1 - self.p2:
            
            MS = self.LS()
        
        else:
            
            MS = self.RF()
                       
        return OS, MS

        
    def decoding(self, OS, MS):
        
        # Step 1
        JM = np.zeros((self.job_num, max(self.machines)))
        T = np.zeros((self.job_num, max(self.machines)))
            
        for i in range(self.job_num):
            
            for j in range(self.machines[i]):
                JM[i][j] = self.operation[i][j][int(MS[int(sum(self.machines[:i])) + j]) - 1]
                T[i][j] = self.operation_time[i][j][int(MS[int(sum(self.machines[:i])) + j]) - 1]
        
        # Step 2
        machinetime = []
        for i in range(self.machine_num):
            machinetime.append([])
        
        jobtime = np.zeros(self.job_num)
        count = np.zeros(self.job_num, dtype=np.int64)
        
        for job in OS:
            Mi = int(JM[job][count[job]]) - 1
             
            if machinetime[Mi] == []:               #机器Mi的第一道工序
                 
                if count[job] == 0:                 #工件job的第一道工序
                    startime = 0
                else:
                    startime = jobtime[job]
            else:
                interval = []
                 
                if int(machinetime[Mi][0][0]) == 0:
                    pass
                else:
                    interval.append([0, machinetime[Mi][0][0]])
                
                if len(machinetime[Mi]) > 1:  
                    
                    for i in range(len(machinetime[Mi]) - 1):
                        if machinetime[Mi][i][1] == machinetime[Mi][i + 1][0]:
                            continue
                        else:
                            interval.append([machinetime[Mi][i][1], machinetime[Mi][i + 1][0]])
                
                if interval == []:
                    startime = max(jobtime[job], machinetime[Mi][-1][1])
                else:
                    for i in range(len(interval)):
                        ta = max(jobtime[job], interval[i][0])
                        if ta + T[job][count[job]] <= interval[i][1]:
                            startime = ta
                            break
                        elif i == len(interval) - 1:
                            startime = max(jobtime[job], machinetime[Mi][-1][1])
            
            jobtime[job] = startime + T[job][count[job]]
            machinetime[Mi].append([startime, startime + T[job][count[job]]])
            machinetime[Mi].sort()
            
            count[job] += 1
     
        finishtime = []
        for i in machinetime:
            if i != []:
                finishtime.append(i[-1][1])
            
        final = max(finishtime)
                
        return final, machinetime , JM, T 
    
    def plot(self, OS, MS):
        
        # Step 1
        JM = np.zeros((self.job_num, max(self.machines)))
        T = np.zeros((self.job_num, max(self.machines)))
            
        for i in range(self.job_num):
            
            for j in range(self.machines[i]):
                JM[i][j] = self.operation[i][j][int(MS[int(sum(self.machines[:i])) + j]) - 1]
                T[i][j] = self.operation_time[i][j][int(MS[int(sum(self.machines[:i])) + j]) - 1]
        
        # Step 2
        machinetime = []
        for i in range(self.machine_num):
            machinetime.append([])
        
        jobtime = np.zeros(self.job_num)
        count = np.zeros(self.job_num, dtype=np.int64)
        
        for job in OS:
            Mi = int(JM[job][count[job]]) - 1
             
            if machinetime[Mi] == []:               #机器Mi的第一道工序
                 
                if count[job] == 0:                 #工件job的第一道工序
                    startime = 0
                else:
                    startime = jobtime[job]
            else:
                interval = []
                 
                if int(machinetime[Mi][0][0]) == 0:
                    pass
                else:
                    interval.append([0, machinetime[Mi][0][0]])
                
                if len(machinetime[Mi]) > 1:  
                    
                    for i in range(len(machinetime[Mi]) - 1):
                        if machinetime[Mi][i][1] == machinetime[Mi][i + 1][0]:
                            continue
                        else:
                            interval.append([machinetime[Mi][i][1], machinetime[Mi][i + 1][0]])
                
                if interval == []:
                    startime = max(jobtime[job], machinetime[Mi][-1][1])
                else:
                    for i in range(len(interval)):
                        ta = max(jobtime[job], interval[i][0])
                        if ta + T[job][count[job]] <= interval[i][1]:
                            startime = ta
                            break
                        elif i == len(interval) - 1:
                            startime = max(jobtime[job], machinetime[Mi][-1][1])
            
            jobtime[job] = startime + T[job][count[job]]
            t = T[job][count[job]]
            machinetime[Mi].append([startime, startime + T[job][count[job]]])
            machinetime[Mi].sort()
            count[job] += 1
            plt.bar(x=startime, bottom=Mi+1, height=0.6, width=t, orientation="horizontal", color = color[job], edgecolor='black')
            plt.text(startime , Mi + 1 - 0.2, 'J%.0f.%.0f' % (job + 1, count[job]), color='black', fontsize=12, weight='bold') 
        
        finishtime = []
        for i in machinetime:
            if i != []:
                finishtime.append(i[-1][1])
            
        final = max(finishtime)
        print(final)
        font1 = {'weight': 'bold', 'size': 15}  # 汉字字体大小，可以修改       
        plt.title("Gantt",font1)
        plt.ylabel("Machines", font1)
        plt.yticks(scale_ls)
        plt.axis([0, final * 1.1, 0, self.machine_num + 1])
        plt.tick_params(labelsize=10)  # 坐标轴刻度字体大小，可以修改
        plt.legend(prop={'family': ['SimHei'], 'size': 10})  # 标签字体大小，可以修改
        plt.xlabel("Processing time", font1)
        plt.show()
                
        return machinetime
                        
                    
#os,ms = FJSP(0.6, 0.3).creat_job()
#a, b = FJSP(0.6, 0.3).operation, FJSP(0.6, 0.3).operation_time
#c, d, e, f = FJSP(0.6, 0.4).decoding(os, ms)
#c = FJSP(0.6, 0.4).plot(os, ms)
