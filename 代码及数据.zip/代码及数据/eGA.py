"""Explanation  
by Kaihan Fu. China university of Petroleum(BJ)

eGA文件是effictive genetic algorithm是实现主体

generation是迭代次数
popsize是种群规模
p1是交叉概率
p2是变异概率
C_size是锦标赛选择个数

MS_Crossover()是机器选择部分的均匀交叉
OS_Crossover()是工序排序部分的PXO交叉
MS_Mutation()是机器选择部分的变异操作
OS_Mutation()是工序排序部分的变异操作
eGA()是遗传算法的主体部分

Output
----------



"""
from file_processing import file_processing
from Initialization import FJSP
import random
import numpy as np
import copy

class eGA():
    
    def __init__(self, generation, popsize, data, p1, p2, C_size):
        self.generation = generation
        self.popsize = popsize
        self.data = data
        self.p1 = p1
        self.p2 = p2
        self.C_size = C_size
        self.operation = data.operation
        self.operation_time = data.operation_time
        self.machines = file_processing().calculation()[5]
        
    def MS_Crossover(self, m1, m2):
        
        r = random.randint(1, len(m1))
        index = random.sample(range(len(m1)), r)

        c1, c2 = np.zeros(len(m1)), np.zeros(len(m1))
        for i in range(len(m1)):
            
            if i in index:
                c1[i] = m1[i]
                c2[i] = m2[i]
            else:
                c1[i] = m2[i]
                c2[i] = m1[i]
        
        return c1, c2
    
    def OS_Crossover(self, j1, j2):
        
        Job = random.sample(range(len(self.machines)), int(len(self.machines)/2))
        job1, job2 = j1.tolist(), j2.tolist()
        c1, c2 = np.zeros(len(j1)), np.zeros(len(j1))
        
        for i in range(len(j1)):
            if j1[i] in Job:
                c1[i] = j1[i]
                job1.remove(j1[i])
            if j2[i] in Job:
                c2[i] = j2[i]
                job2.remove(j2[i])

        for i in range(len(job2)):
            
            for j in range(len(c1)):
                if c1[j] == 0:
                    c1[j] = job2[i]
                    break
                
        for i in range(len(job1)):
            
            for j in range(len(c2)):
                if c2[j] == 0:
                    c2[j] = job1[i]
                    break            
        c1, c2 = np.array(c1), np.array(c2)   
        c1, c2 = c1.astype(int), c2.astype(int)             
        return c1, c2
    
    def MS_Mutation(self, m1):
        
        r = random.randint(1, len(m1))
        index = random.sample(range(len(m1)), r)
        
        for i in index:
            
            for j in range(len(self.machines)):
                if i < sum(self.machines[:j+1]):
                    index0 = j
                    index1 = i - sum(self.machines[:j])
                    break
                
            m1[i] = self.operation_time[index0][index1].index(min(self.operation_time[index0][index1])) + 1
        
        return m1
    
    def OS_Mutation(self, j1):

        index = random.sample(range(len(j1)), 2)
        j1[index[0]], j1[index[1]] = j1[index[1]], j1[index[0]]
        
        return j1
    
    def ega(self):
        
        Job, Machine, makespan = [], [], []
        for i in range(self.popsize):
            OS, MS = self.data.creat_job()
            final, machines, _, _ = self.data.decoding(OS, MS)
            Job.append(OS)
            Machine.append(MS)
            makespan.append(final)
        print('种群初始的完工时间:%.0f' % (min(makespan)))
        
        for gen in range(self.generation):
            
            answer, job, machine = [], [], []
            
            for i in range(self.popsize - 1):
                OS1, MS1 = Job[i], Machine[i]
                OS2, MS2 = Job[i+1], Machine[i+1]
                
                if np.random.rand() < self.p1:
                    OS1, OS2 = self.OS_Crossover(OS1, OS2)
                    MS1, MS2 = self.MS_Crossover(MS1, MS2)

                if np.random.rand() < self.p2:
                    OS1 = self.OS_Mutation(OS1)
                    MS1 = self.MS_Mutation(MS1)
                
                final, _, _, _ = self.data.decoding(OS1, MS1)    
                answer.append(final)
                job.append(OS1)
                machine.append(MS1)
                
            fjob, fmachine = np.vstack((Job, job)), np.vstack((Machine, machine))
            fmakespan = makespan + answer      
            best = fmakespan.index(min(fmakespan))
            if gen <= self.generation - 1:
                print('遗传算法第%.0f次迭代的完工时间:%.0f' % (gen + 1, min(fmakespan)))
            
            for i in range(self.popsize):
                cab = random.sample(range(len(fjob)), self.C_size)      # 按照C_size生成一组不重复的索引用于锦标赛选择
                index, time = [], []
                for j in range(self.C_size):
                    index.append(cab[j]), time.append(fmakespan[cab[j]])
                min_time = time.index(min(time))
                min_idx = index[min_time]
                Job[i], Machine[i] = fjob[min_idx], fmachine[min_idx]  # 选择出的个体，用于下次遗传
                makespan[i] = fmakespan[min_idx]
      
        return fjob[best],fmachine[best]
    
# data = FJSP(0.6, 0.2)    
# test = eGA(100, 500, data, 0.9, 0.008, 2)
# a, b = test.ega()